# Source-built AppImage type-2 runtime (ssc-j2ps)

Input source archives are copied unchanged from SSC packaging/third-party-sources/appimage-runtime.
`source-checksums.sha256` identifies every input. The supplied patched fuse archive is used directly.

## Offline reproduction and LGPL relinking

On an x86_64 Linux host with bash, tar, sha256sum and bubblewrap/user namespaces, unpack this bundle and run:

```
./setup-offline.sh > build-offline.log 2>&1
```

The setup verifies the official Alpine 3.21.8 minirootfs SHA256 and every captured compiler APK,
extracts a private rootfs, installs these APK files with `--no-network`, and compiles with two workers.
`run-alpine-offline.sh` disables network access for the entire environment. No host install or sudo.
The Alpine checksum was fetched from official HTTPS; it was not GPG-authenticated.

To exercise LGPL freedom to modify/relink libfuse, unpack `sources/fuse-3.15.0-appimage-patched.tar.xz`
into a new `modified-fuse/` directory under this bundle, edit the resulting `modified-fuse/fuse-3.15.0`
sources, then run:

```
./run-alpine-offline.sh /usr/bin/env FUSE_SOURCE=/build/modified-fuse/fuse-3.15.0 /bin/bash /build/build-offline.sh
```

Use a fresh libfuse source tree without an existing build directory. The full runtime and all other
static dependencies remain available as source and rebuild locally; there is no unmodifiable application object.
Upstream licenses/notices are preserved inside each input archive, including LGPL libfuse license files.

## Build differences from upstream driver

Upstream Makefile is used for final runtime compilation, with GCC instead of clang so an explicit
source-musl compiler wrapper controls libc provenance. Wrapper specs suppress Alpine GCC's injected
`-lssp_nonshared` and select source-musl rcrt1 for static PIE. `-fno-stack-protector` is explicit.
The sole GCC warning downgraded from Werror is upstream runtime.c:734 `-Wformat-overflow`;
source code is unchanged. All other warnings remain errors. mimalloc's versioned library directory
is added to the library search path. Workers are restricted to two.

Static application dependencies: source-musl 1.2.5, zlib 1.3.2, zstd 1.5.6,
mimalloc 2.1.7, patched libfuse 3.15.0, squashfuse 0.5.2. Final link map in output/runtime.map
identifies these archives. GCC14.2 compiler support crtbegin/crtend/libgcc/libgcc_eh are provided
by captured APK toolchain packages, whose exact list/hashes are included; no APK libfuse,
squashfuse, compression, mimalloc or musl libc archive is linked into the runtime.

Validation: static PIE has no PT_INTERP or NEEDED libraries, --appimage-version returns
8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa. output/runtime-x86_64.sha256 identifies the result.

The distribution source/recipe archive intentionally omits the 228 MiB compiler APK set.
That exact set is retained separately in the owner build environment's `downloads/apks/`;
copy it into the unpacked bundle's same path before using `setup-offline.sh`.
`compiler-apk-checksums.sha256` verifies each package. No download is hidden in the offline recipe.
