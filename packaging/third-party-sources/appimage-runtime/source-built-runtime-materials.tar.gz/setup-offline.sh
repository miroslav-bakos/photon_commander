#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
(cd downloads && sha256sum -c alpine-minirootfs-3.21.8-x86_64.tar.gz.sha256)
sha256sum -c compiler-apk-checksums.sha256
mkdir -p rootfs work
if [[ ! -e rootfs/bin/busybox ]]; then
  tar --no-same-owner -xzf downloads/alpine-minirootfs-3.21.8-x86_64.tar.gz -C rootfs
fi
./run-alpine-offline.sh /bin/sh -c 'apk add --no-network /build/downloads/apks/*.apk'
./run-alpine-offline.sh /bin/bash /build/build-offline.sh
