AppImage runtime source and rebuilding materials

Runtime: AppImage/type2-runtime 8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa.
Full upstream source, linker script, patches, Makefile and both build methods
are in type2-runtime-8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa.tar.gz.
Sources and license texts accompany this distribution; no source download
or written offer is needed to obtain the included code.

libfuse 3.15.0: original upstream archive plus a separate complete source
archive with upstream runtime's patches/libfuse/mount.c.diff applied.
Squashfuse 0.5.2, musl 1.2.5, zstd 1.5.6, zlib 1.3.2 and mimalloc 2.1.7
are provided as complete upstream source archives.
Alpine package build recipes and patches are included for musl, zlib,
zstd and mimalloc2 at aports b82a90a26fc0965ffd03cca90dfb1daed17101cc,
the latest 3.21-stable commit preceding the runtime release build.

Rebuild/relink the runtime independently of the proprietary application:
1. Extract the full runtime archive and dependency archives.
2. Consult runtime BUILD.md and scripts/docker/Dockerfile or the chroot path.
3. Build/install the included static dependencies. Use included Alpine
   APKBUILD files and patches when reproducing their packaged variants.
   scripts/common/install-dependencies.sh gives exact fuse/squashfuse
   checksums/configuration; substitute the supplied archives for downloads.
4. Make changes to libfuse if desired, rebuild its static library, and run
   scripts/build-runtime.sh. src/runtime/Makefile links the runtime anew.
5. Use appimagetool --runtime-file with the rebuilt runtime and extracted
   application AppDir to create the replacement AppImage container.
   The proprietary payload stays separate; runtime source is unrestricted
   except for the accompanying component licenses.

Provenance limitation: upstream did not publish a package-level SBOM or
immutable Alpine repository snapshot. zlib 1.3.2 and zstd 1.5.6 are visible
in the downloaded runtime; fuse/squashfuse versions are explicitly pinned.
The Alpine musl/mimalloc versions and package patches follow the documented
build baseline, but exact binary correspondence of those inputs has not
been proven. Do not describe this collection as a verified reproducible
build of the downloaded upstream runtime without resolving that gap.

SOURCE-MANIFEST.json records source URLs and SHA-256 checksums. Locally
prepared archives derive from those upstream sources without application
code. Full licenses are in third-party-licenses/appimage-runtime/.
