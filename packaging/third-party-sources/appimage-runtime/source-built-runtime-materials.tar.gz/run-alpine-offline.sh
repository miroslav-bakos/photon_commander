#!/usr/bin/env bash
set -euo pipefail
ENV_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec bwrap --unshare-net --unshare-user --uid 0 --gid 0 --unshare-pid --unshare-uts --unshare-ipc --die-with-parent \
 --bind "$ENV_ROOT/rootfs" / --proc /proc --dev /dev --tmpfs /tmp \
 --ro-bind /etc/resolv.conf /etc/resolv.conf --bind "$ENV_ROOT" /build \
 --setenv HOME /root --setenv PATH /usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin --chdir /build "$@"
