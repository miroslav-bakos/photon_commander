#!/bin/bash
set -euxo pipefail
# Inputs stay local. This script performs no downloads and uses two workers.
cd /build
sha256sum -c source-checksums.sha256
mkdir -p work output
for archive in sources/musl-1.2.5.tar.gz sources/zlib-1.3.2.tar.gz sources/zstd-1.5.6.tar.gz sources/mimalloc-2.1.7.tar.gz sources/squashfuse-0.5.2.tar.gz sources/fuse-3.15.0-appimage-patched.tar.xz sources/type2-runtime-8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa.tar.gz; do tar xf "$archive" -C work; done
cd work/musl-1.2.5
./configure --prefix=/opt/source-musl --enable-static --disable-shared --enable-wrapper=gcc
make -j2
make install
printf '*link_ssp:\n%%{!fno-stack-protector:}\n\n' > /opt/source-musl/lib/no-ssp.specs
sed -i 's| -specs | -specs /opt/source-musl/lib/no-ssp.specs -specs |' /opt/source-musl/bin/musl-gcc
sed -i 's|%{!shared: /opt/source-musl/lib/Scrt1.o}|%{!shared:%{static-pie:/opt/source-musl/lib/rcrt1.o;:/opt/source-musl/lib/Scrt1.o}}|' /opt/source-musl/lib/musl-gcc.specs
sed -i 's|%{static:-static}|%{static:-static} %{static-pie:-static -pie --no-dynamic-linker -z text}|' /opt/source-musl/lib/musl-gcc.specs
export CC=/opt/source-musl/bin/musl-gcc
export CFLAGS='-Os -fno-stack-protector -ffunction-sections -fdata-sections -fPIC'
export CPPFLAGS=-I/opt/source/include
export LDFLAGS=-L/opt/source/lib
export PKG_CONFIG_PATH=/opt/source/lib/pkgconfig
for d in linux asm asm-generic; do ln -sfn /usr/include/$d /opt/source-musl/include/$d; done
cd /build/work/zlib-1.3.2
./configure --prefix=/opt/source --static
make -j2
make install
cd /build/work/zstd-1.5.6
make -j2 lib-release CC="$CC" PREFIX=/opt/source ZSTD_LEGACY_SUPPORT=0
make -C lib install-static install-includes install-pc PREFIX=/opt/source
cd /build/work/mimalloc-2.1.7
cmake -S . -B build -DCMAKE_C_COMPILER="$CC" -DCMAKE_INSTALL_PREFIX=/opt/source -DMI_BUILD_SHARED=OFF -DMI_BUILD_OBJECT=OFF -DMI_BUILD_TESTS=OFF
cmake --build build -j2
cmake --install build
cd "${FUSE_SOURCE:-/build/work/fuse-3.15.0}"
meson setup build --prefix=/opt/source --libdir=lib --default-library=static -Dutils=false -Dexamples=false -Dtests=false -Duseroot=false
ninja -C build -j2
ninja -C build install
cd /build/work/squashfuse-0.5.2
./autogen.sh
./configure --prefix=/opt/source --disable-shared --enable-static --without-xz --without-lzo --without-lz4 --with-zstd=/opt/source --with-zlib=/opt/source
make -j2
make install
mkdir -p /opt/source/include/squashfuse
install -m644 ./*.h /opt/source/include/squashfuse/
cd /build/work/type2-runtime-8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa/src/runtime
printf '%s\n' 8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa > version
make -B -j2 CC="$CC" CFLAGS='-std=gnu99 -Os -fno-stack-protector -D_FILE_OFFSET_BITS=64 -DGIT_COMMIT=\"8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa\" -T data_sections.ld -ffunction-sections -fdata-sections -Wl,--gc-sections -static -Wall -Werror -Wno-error=format-overflow -static-pie -I/opt/source/include/squashfuse -I/opt/source/include/fuse3 -I/opt/source/include -L/opt/source/lib -L/opt/source/lib/mimalloc-2.1 -Wl,-Map,/build/output/runtime.map' runtime
objcopy --only-keep-debug runtime /build/output/runtime-x86_64.debug
strip --strip-debug --strip-unneeded runtime
cp runtime /build/output/runtime-x86_64
printf 'AI\002' | dd of=/build/output/runtime-x86_64 bs=1 count=3 seek=8 conv=notrunc
cd /build/output
sha256sum runtime-x86_64 > runtime-x86_64.sha256
file runtime-x86_64
readelf -d runtime-x86_64
./runtime-x86_64 --appimage-version
